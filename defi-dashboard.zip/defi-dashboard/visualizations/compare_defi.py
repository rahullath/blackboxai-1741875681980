import os
import json
import logging
import plotly.graph_objects as go
import plotly.subplots as sp
from typing import Dict, List

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('visualizations.log')
    ]
)

class DeFiVisualizer:
    def __init__(self):
        self.data_path = 'data/processed/processed_data.json'
        self.output_dir = 'visualizations/output'
        
        # Ensure output directory exists
        os.makedirs(self.output_dir, exist_ok=True)

    def load_data(self) -> Dict:
        """
        Load the processed data from JSON file.
        
        Returns:
            Dict: Processed protocol data
        """
        try:
            with open(self.data_path, 'r') as f:
                data = json.load(f)
            logging.info("Processed data loaded successfully")
            return data
            
        except FileNotFoundError:
            logging.error(f"Processed data file not found: {self.data_path}")
            raise
        except json.JSONDecodeError as e:
            logging.error(f"Error decoding JSON data: {str(e)}")
            raise

    def create_market_cap_chart(self, protocols: List[Dict]) -> go.Figure:
        """
        Create a bar chart comparing market caps.
        
        Args:
            protocols (List[Dict]): List of protocol data
            
        Returns:
            go.Figure: Plotly figure object
        """
        names = [p["displayName"] for p in protocols]
        market_caps = [p["metrics"]["marketCap"] / 1e6 for p in protocols]  # Convert to millions
        
        fig = go.Figure(data=[
            go.Bar(
                x=names,
                y=market_caps,
                text=[f"${x:.2f}M" for x in market_caps],
                textposition='auto',
            )
        ])
        
        fig.update_layout(
            title="Market Cap Comparison",
            xaxis_title="Protocol",
            yaxis_title="Market Cap (Millions USD)",
            template="plotly_white"
        )
        
        return fig

    def create_revenue_chart(self, protocols: List[Dict]) -> go.Figure:
        """
        Create a bar chart comparing annual revenues.
        
        Args:
            protocols (List[Dict]): List of protocol data
            
        Returns:
            go.Figure: Plotly figure object
        """
        names = [p["displayName"] for p in protocols]
        revenues = [self.calculate_last_12_months_revenue(p["monthly_revenue"]) / 1e6 for p in protocols]  # Aggregate last 12 months and convert to millions
        
        fig = go.Figure(data=[
            go.Bar(
                x=names,
                y=revenues,
                text=[f"${x:.2f}M" for x in revenues],
                textposition='auto',
            )
        ])
        
        fig.update_layout(
            title="Annual Revenue Comparison",
            xaxis_title="Protocol",
            yaxis_title="Annual Revenue (Millions USD)",
            template="plotly_white"
        )
        
        return fig

    def calculate_last_12_months_revenue(self, monthly_revenue: Dict) -> float:
        """
        Calculate the total revenue for the last 12 months.
        
        Args:
            monthly_revenue (Dict): Monthly revenue data
            
        Returns:
            float: Total revenue for the last 12 months
        """
        sorted_months = sorted(monthly_revenue.keys(), reverse=True)
        last_12_months = sorted_months[:12]
        return sum(monthly_revenue[month] for month in last_12_months)

    def create_qoq_growth_chart(self, protocols: List[Dict]) -> go.Figure:
        """
        Create a bar chart comparing QoQ revenue growth.
        
        Args:
            protocols (List[Dict]): List of protocol data
            
        Returns:
            go.Figure: Plotly figure object
        """
        names = [p["displayName"] for p in protocols]
        growth_rates = [self.calculate_qoq_growth(p["monthly_revenue"]) * 100 for p in protocols]  # Convert to percentage
        
        fig = go.Figure(data=[
            go.Bar(
                x=names,
                y=growth_rates,
                text=[f"{x:.2f}%" for x in growth_rates],
                textposition='auto',
            )
        ])
        
        fig.update_layout(
            title="QoQ Revenue Growth Comparison",
            xaxis_title="Protocol",
            yaxis_title="QoQ Revenue Growth (%)",
            template="plotly_white"
        )
        
        return fig

    def calculate_qoq_growth(self, monthly_revenue: Dict) -> float:
        """
        Calculate the quarter-over-quarter (QoQ) growth rate from monthly revenue data.
        
        Args:
            monthly_revenue (Dict): Monthly revenue data
            
        Returns:
            float: QoQ growth rate
        """
        # Extract the last 12 months of revenue data
        sorted_months = sorted(monthly_revenue.keys(), reverse=True)
        if len(sorted_months) < 12:
            return 0.0
        
        last_quarter = sum(monthly_revenue[month] for month in sorted_months[:3])
        previous_quarter = sum(monthly_revenue[month] for month in sorted_months[3:6])
        
        if previous_quarter == 0:
            return 0.0
        
        return (last_quarter - previous_quarter) / previous_quarter

    def create_chain_comparison_chart(self, chains: Dict) -> go.Figure:
        """
        Create a bar chart comparing chain revenues.
        
        Args:
            chains (Dict): Chain data
            
        Returns:
            go.Figure: Plotly figure object
        """
        chain_names = list(chains.keys())
        revenues = []
        for chain in chain_names:
            monthly_revenue = chains[chain]["monthly_revenue"]
            if isinstance(monthly_revenue, dict):
                total_revenue = sum(monthly_revenue.values())
            elif isinstance(monthly_revenue, (int, float)):
                total_revenue = monthly_revenue
            else:
                total_revenue = 0
            revenues.append(total_revenue / 1e6)  # Convert to millions
        
        fig = go.Figure(data=[
            go.Bar(
                x=chain_names,
                y=revenues,
                text=[f"${x:.2f}M" for x in revenues],
                textposition='auto',
            )
        ])
        
        fig.update_layout(
            title="Chain Revenue Comparison",
            xaxis_title="Chain",
            yaxis_title="Revenue (Millions USD)",
            template="plotly_white"
        )
        
        return fig

    def create_protocol_contribution_chart(self, protocols: List[Dict], chains: Dict) -> go.Figure:
        """
        Create a bubble map showing protocol contributions to chains.
        
        Args:
            protocols (List[Dict]): List of protocol data
            chains (Dict): Chain data
            
        Returns:
            go.Figure: Plotly figure object
        """
        bubble_data = []
        for protocol in protocols:
            for chain in protocol["chains"]:
                if chain in chains:
                    bubble_data.append({
                        "chain": chain,
                        "protocol": protocol["displayName"],
                        "revenue": protocol["metrics"]["revenue"]
                    })
        
        if bubble_data:
            max_revenue = max([d["revenue"] / 1e6 for d in bubble_data])
        else:
            max_revenue = 1  # Avoid division by zero
        
        fig = go.Figure(data=[
            go.Scatter(
                x=[d["chain"] for d in bubble_data],
                y=[d["protocol"] for d in bubble_data],
                mode='markers',
                marker=dict(
                    size=[d["revenue"] / 1e6 for d in bubble_data],  # Convert to millions
                    sizemode='area',
                    sizeref=2.*max_revenue/(40.**2),
                    sizemin=4
                ),
                text=[f"${d['revenue']:.2f}" for d in bubble_data]
            )
        ])
        
        fig.update_layout(
            title="Protocol Revenue Contribution to Chains",
            xaxis_title="Chain",
            yaxis_title="Protocol",
            template="plotly_white"
        )
        
        return fig

    def create_tvl_chart(self, protocols: List[Dict]) -> go.Figure:
        """
        Create a bar chart comparing total value locked (TVL).
        
        Args:
            protocols (List[Dict]): List of protocol data
            
        Returns:
            go.Figure: Plotly figure object
        """
        names = [p["displayName"] for p in protocols]
        tvls = [p["metrics"]["tvl"] / 1e6 for p in protocols]  # Convert to millions
        
        fig = go.Figure(data=[
            go.Bar(
                x=names,
                y=tvls,
                text=[f"${x:.2f}M" for x in tvls],
                textposition='auto',
            )
        ])
        
        fig.update_layout(
            title="Total Value Locked (TVL) Comparison",
            xaxis_title="Protocol",
            yaxis_title="TVL (Millions USD)",
            template="plotly_white"
        )
        
        return fig

    def create_fees_chart(self, protocols: List[Dict]) -> go.Figure:
        """
        Create a bar chart comparing protocol fees.
        
        Args:
            protocols (List[Dict]): List of protocol data
            
        Returns:
            go.Figure: Plotly figure object
        """
        names = [p["displayName"] for p in protocols]
        fees = [p["metrics"]["fees"] / 1e6 for p in protocols]  # Convert to millions
        
        fig = go.Figure(data=[
            go.Bar(
                x=names,
                y=fees,
                text=[f"${x:.2f}M" for x in fees],
                textposition='auto',
            )
        ])
        
        fig.update_layout(
            title="Protocol Fees Comparison",
            xaxis_title="Protocol",
            yaxis_title="Fees (Millions USD)",
            template="plotly_white"
        )
        
        return fig

    def create_dashboard(self):
        """
        Create the DeFi dashboard with multiple charts.
        """
        data = self.load_data()
        protocols = data["protocols"]
        chains = data["chains"]
        
        market_cap_chart = self.create_market_cap_chart(protocols)
        revenue_chart = self.create_revenue_chart(protocols)
        qoq_growth_chart = self.create_qoq_growth_chart(protocols)
        chain_comparison_chart = self.create_chain_comparison_chart(chains)
        protocol_contribution_chart = self.create_protocol_contribution_chart(protocols, chains)
        tvl_chart = self.create_tvl_chart(protocols)
        fees_chart = self.create_fees_chart(protocols)
        
        # Create a subplot with 7 rows and 1 column
        fig = sp.make_subplots(
            rows=7, cols=1,
            subplot_titles=(
                "Market Cap Comparison",
                "Annual Revenue Comparison",
                "QoQ Revenue Growth Comparison",
                "Chain Revenue Comparison",
                "Protocol Revenue Contribution to Chains",
                "Total Value Locked (TVL) Comparison",
                "Protocol Fees Comparison"
            ),
            vertical_spacing=0.1
        )
        
        fig.add_trace(market_cap_chart.data[0], row=1, col=1)
        fig.add_trace(revenue_chart.data[0], row=2, col=1)
        fig.add_trace(qoq_growth_chart.data[0], row=3, col=1)
        fig.add_trace(chain_comparison_chart.data[0], row=4, col=1)
        fig.add_trace(protocol_contribution_chart.data[0], row=5, col=1)
        fig.add_trace(tvl_chart.data[0], row=6, col=1)
        fig.add_trace(fees_chart.data[0], row=7, col=1)
        
        fig.update_layout(
            height=2100,
            title_text="DeFi Protocol Comparison Dashboard",
            showlegend=False,
            template="plotly_white"
        )
        
        output_file = os.path.join(self.output_dir, "defi_dashboard.html")
        fig.write_html(output_file)
        logging.info(f"Dashboard successfully created at {output_file}")

def main():
    """Main execution function."""
    try:
        visualizer = DeFiVisualizer()
        visualizer.create_dashboard()
        logging.info("Dashboard creation completed successfully")
        
    except Exception as e:
        logging.error(f"Unexpected error during execution: {str(e)}")
        raise

if __name__ == "__main__":
    main()
